# Cactus post-review QuaSSE plotting

library(diversitree)
library(ggplot2)
library(ggpubr)

setwd("C:/Users/jamie/OneDrive/Documents/Cacti round 2")
setwd("/home/ubuntu/cacti")

db <- read.csv ("Round_2_combined_data_for_xgboost.csv", h = T, stringsAsF = F)
db$X = NULL
rownames(db) <- db$species
db$species = NULL
db$biome = NULL

# Need to do this for bio2, soil sand, size, bio3, geog range size


# For sand
sand = na.omit(db[c("lambda","sand")])
traits = log(sand$sand)

# get trait range
traits.range = range(traits)
# dummy X/trait variable
traits.x = seq(traits.range[1], traits.range[2], length.out=100) # this is for 100 evenly sampled trait space points.
# apply dummy X to results of ML fit using the Gaussian function
speciation.y = noroptimal.x(traits.x, y0= 1.360578e-05, y1=2.312607e-01, xmid=3.879164e+00, s2=2.321756e-02)
# simple plot
plot(traits.x, speciation.y, type="l")

sand_df = data.frame(traits=traits.x, speciation.rate=speciation.y)
sand_plot = ggplot(sand_df, aes(x=traits, y=speciation.rate)) + geom_line() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  xlab("Soil sand content (log %)") +
  ylab("Speciation rate")+
  ylim(c(0, max(speciation.y)))

# Bio2

bio2 = na.omit(db[c("lambda","bio2")])
traits = bio2

#############
# get trait range
traits.range = range(traits)
# dummy X/trait variable
traits.x = seq(traits.range[1], traits.range[2], length.out=100) # this is for 100 evenly sampled trait space points.
# apply dummy X to results of ML fit using the Gaussian function
speciation.y = noroptimal.x(traits.x, y0= 5.594774e-02, y1=3.056510e+00, xmid=1.020159e+01, s2 = 2.557446e-04)
# simple plot
plot(traits.x, speciation.y, type="l")

bio2_df = data.frame(traits=traits.x, speciation.rate=speciation.y)
bio2_plot = ggplot(bio2_df, aes(x=traits, y=speciation.rate)) + geom_line() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  xlab("Diurnal air temp. range (�C)") +
  ylab("Speciation rate")+
  ylim(c(0, max(speciation.y)))

# Size

size = na.omit(db[c("lambda","size")])
traits = log(size$size+1)

#############
# get trait range
traits.range = range(traits)
# dummy X/trait variable
traits.x = seq(traits.range[1], traits.range[2], length.out=100) # this is for 100 evenly sampled trait space points.
# apply dummy X to results of ML fit using the Gaussian function
speciation.y = noroptimal.x(traits.x, y0= 8.598642e+06, y1=6.636214e-02, xmid=3.844792e+00, s2 = 4.855244e+07)
# simple plot
plot(traits.x, speciation.y, type="l")

size_df = data.frame(traits=traits.x, speciation.rate=speciation.y)
size_plot = ggplot(size_df, aes(x=traits, y=speciation.rate)) + geom_line() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  xlab("Plant size (log cm+1)") +
  ylab("Speciation rate")+
  ylim(c(0, max(speciation.y)))

# Isothermality - check if need to divide by 10

bio3 = na.omit(db[c("lambda","bio3")])
traits = bio3$bio3

# get trait range
traits.range = range(traits)
# dummy X/trait variable
traits.x = seq(traits.range[1], traits.range[2], length.out=100) # this is for 100 evenly sampled trait space points.
# apply dummy X to results of ML fit using the Gaussian function
speciation.y = noroptimal.x(traits.x, y0=4.458900e-02, y1=8.925898e-01, xmid=5.455912e-01, s2=7.414003e-06)
# simple plot
plot(traits.x, speciation.y, type="l")

bio3_df = data.frame(traits=traits.x, speciation.rate=speciation.y)
bio3_plot = ggplot(bio3_df, aes(x=traits, y=speciation.rate)) + geom_line() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  xlab("Isothermality (�C)") +
  ylab("Speciation rate")+
  ylim(c(0, max(speciation.y)))

# For range size - checked January

range_size = na.omit(db[c("lambda","range_size")])
traits = log(range_size$range_size)

# get trait range
traits.range = range(traits)
# dummy X/trait variable
traits.x = seq(traits.range[1], traits.range[2], length.out=500) # this is for 100 evenly sampled trait space points.
# apply dummy X to results of ML fit using the Gaussian function
speciation.y = noroptimal.x(traits.x, y0=8.806118e-02, y1=3.868752e+00, xmid=-1.469677e+00, s2=3.691355e-05)
# simple plot
plot(traits.x, speciation.y, type="l")

range_df = data.frame(traits=traits.x, speciation.rate=speciation.y)
range_plot = ggplot(range_df, aes(x=traits, y=speciation.rate)) + geom_line() +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black")) +
  xlab(expression(paste("Range size (log AOO)"))) +
  ylab("Speciation rate")
range_plot

ggarrange(bio2_plot,sand_plot,size_plot,bio3_plot,range_plot,ncol=2,nrow=3)
# 1,000*622 pixels

pdf("New QuaSSE figure.pdf")
ggarrange(bio2_plot,sand_plot,size_plot,bio3_plot,range_plot,ncol=2,nrow=3)
dev.off()

pdf("QuaSSE plots March elev and slope sigmoidal.pdf")
abs_lat_plot #
size_plot
sand_plot
bio18_plot #
elev_plot
bio2_plot #
range_plot
prof_plot
slope_plot
dev.off()