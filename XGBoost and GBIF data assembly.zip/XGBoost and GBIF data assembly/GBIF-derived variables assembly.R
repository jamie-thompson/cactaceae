# Cactus gbif

library(ape)
library(dplyr)
library(phangorn)
library(raster)
library(speciesmap)
library(sf)
library(sp)
library(phangorn)

setwd("")

# Read tree and coordinates data
cactus_tree = force.ultrametric(read.tree("ultra_cacti.tre"))
cactus_data = read.csv("Thompson_gbif.csv") # The curated GBIF coordinates

# Write list of species sampled to a file for easy reference later
cactus_taxa = as.character(cactus_tree$tip.label)
write(cactus_taxa,"cactus_tree_taxon_list.txt")

# Sub spaces for underscores to match with the tree
# Change SOME (not all!) of the Pereskia to Leuenbergeria to maximise GBIF coverage of Pereskioideae
cactus_data$species = sub(" ", "_", cactus_data$species)
cactus_data$species = sub("Pereskia_bleo", "Leuenbergeria_bleo", cactus_data$species)
cactus_data$species = sub("Pereskia_guamacho", "Leuenbergeria_guamacho", cactus_data$species)
cactus_data$species = sub("Pereskia_lychnidiflora", "Leuenbergeria_lychnidiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_aureiflora", "Leuenbergeria_aureiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_zinniiflora", "Leuenbergeria_zinniiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_marcanoi", "Leuenbergeria_marcanoi", cactus_data$species)
cactus_data$species = sub("Pereskia_portulacifolia", "Leuenbergeria_portulacifolia", cactus_data$species)

# Write species sampled in GBIF for later use
unique_cactus_species = unique(cactus_data$species)
write(unique_cactus_species,"cactus_gbif_unique_species.txt")

# Find spaces sampled by both the tree and GBIF
cactus_tree_taxa_in_gbif = data.frame(species = intersect(cactus_data$species, cactus_tree$tip.label))
cactus_gbif = semi_join(cactus_data,cactus_tree_taxa_in_gbif,by = "species")

# Prune tree to just taxa overlapping with GBIF
cactus_gbif_tree = keep.tip(cactus_tree,unique(cactus_gbif$species))

# Now extract the 19 bioclimatic variables
sp = cactus_gbif[,c("species","decimalLatitude","decimalLongitude")]
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
options(worldclimpath = ".../worldclim") # Following https://rdrr.io/github/RemkoDuursma/speciesmap/src/R/worldclim.R
env <- getData('worldclim', var='bio', res=10)
xy_bio <- raster::extract(env, xy)
sp_m_bio <- cbind(sp_xy, xy_bio) # This one I changed from "sp_m" in the tutorial.  CHECK THIS WORKS WITH MULTIPLE SPECIES IN THE SAME DATASET.

# Write all to file
write.csv(sp_m_bio, "cactus_bioclim_results.csv")

# Calculate median for 19 bioclimatic variables and latitude
cactus_bioclim_median = aggregate(.~species, sp_m_bio, median)
write.csv(cactus_bioclim_median, "median_cactus_bioclim_results.csv")

# Extract potential evapotranspiration and aridity index - from https://figshare.com/articles/dataset/Global_Aridity_Index_and_Potential_Evapotranspiration_ET0_Climate_Database_v2/7504448/3
ai = raster("ai_et0.tif")
ai_xy_bio <- raster::extract(ai, xy)
ai_bio <- cbind(sp_xy, ai_xy_bio)
write.csv(ai_bio,"all_cactus_AI.csv")

median_ai = aggregate(.~species, ai_bio, median)
median_ai = median_ai[c("species","ai_xy_bio")]
write.csv(median_ai,"cactus_median_AI.csv")

pet = raster("et0_yr.tif")
pet_xy_bio <- raster::extract(pet, xy)
pet_bio <- na.omit(cbind(sp_xy, pet_xy_bio))
write.csv(pet_bio,"all_cactus_PET.csv")

median_pet = aggregate(.~species, pet_bio, median)
median_pet = median_pet[c("species","pet_xy_bio")]
write.csv(median_pet,"cactus_median_PET.csv")

# Elevation - from https://www.earthenv.org/topography
elev = raster("elevation_5KMmd_GMTEDmd.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(elev, xy)
elev_bio <- cbind(sp_xy, xy_bio)
write.csv(elev_bio,"cactus_elev.csv")

all_elev = aggregate(elev_bio$xy_bio,list(elev_bio$species),median)
write.csv(all_elev,"median_elev.csv")

# Biomes, with code from https://gis.stackexchange.com/questions/376280/converting-a-component-of-a-shapefile-into-a-geotiff-file-in-r
# Load packages
packs <- list("tidyverse", "raster", "sf", "fasterize")
lapply(packs, require, character.only = T)

# Load shapefile
wwf_shp <- st_read("Terrestrial_Ecoregions_World.shp", stringsAsFactors = F) # Data from https://globil-panda.opendata.arcgis.com/datasets/af92f20b1b43479581c819941e0f75ea_0/geoservice?geometry=11.953%2C-89.797%2C-11.953%2C78.032

# Rasterize biome field and write to disk
raster(resolution = 1, crs = "+proj=longlat +datum=WGS84", vals = 0) %>% 
  fasterize(wwf_shp, ., field = "BIOME") %>% 
  writeRaster(., "biomes.tif")

biome = raster("biomes.tif") # http://worldmap.harvard.edu/data/geonode:wwf_terr_ecos_oRn

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(biome, xy)
biome_bio <- na.omit(cbind(sp_xy, xy_bio))
write.csv(biome_bio, "cactus_biome.csv")

all_biome = aggregate(biome_bio$xy_bio,list(biome_bio$species),getmode)
write.csv(all_biome,"biome_mode.csv",quote=FALSE)

# Sand, texture and water - from https://github.com/ISRICWorldSoil/SoilGrids250m

sand = raster("SNDPPT_M_sl1_250m_ll.tif")
texture = raster("TEXMHT_M_sl1_250m_ll.tif")
water = raster("AWCh1_M_sl1_250m_ll.tif")

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]

xy_bio <- raster::extract(sand, xy)
sand_bio <- cbind(sp_xy, xy_bio)

xy_bio <- raster::extract(texture, xy)
texture_bio <- cbind(sp_xy, xy_bio)

xy_bio <- raster::extract(water, xy)
water_bio <- cbind(sp_xy, xy_bio)

sand_bio = na.omit(sand_bio)
texture_bio = na.omit(texture_bio)
water_bio = na.omit(water_bio)

write.csv(sand_bio,"cacti_sand_0cm.csv")
write.csv(water_bio,"cacti_water_0cm.csv")
write.csv(texture_bio,"cacti_texture.csv")

getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

all_sand = aggregate(sand_bio$xy_bio,list(sand_bio$species),median)
all_texture = aggregate(texture_bio$xy_bio,list(texture_bio$species),getmode)
all_water = aggregate(water_bio$xy_bio,list(water_bio$species),median)

write.csv(all_sand,"median_sand_0cm.csv")
write.csv(all_water,"median_water_0cm.csv")
write.csv(all_texture,"mode_texture.csv")

# Slope - from https://www.earthenv.org/topography

slope = raster("slope_1KMmd_GMTEDmd.tif")
xy_bio <- raster::extract(slope, xy)
slope_bio <- cbind(sp_xy, xy_bio)
slope_bio = na.omit(slope_bio)
write.csv(slope_bio,"cacti_slope.csv")

all_slope = aggregate(slope_bio$xy_bio,list(slope_bio$species),median)
write.csv(all_slope,"median_slope.csv")

# Standard deviation of slope - from https://www.earthenv.org/topography

sd_slope = raster("slope_1KMsd_GMTEDmd.tif")
xy_bio <- raster::extract(sd_slope, xy)
sd_slope_bio <- cbind(sp_xy, xy_bio)
sd_slope_bio = na.omit(sd_slope_bio)
write.csv(sd_slope_bio, "cacti_stdev_slope.csv")

all_sd_slope = aggregate(sd_slope_bio$xy_bio,list(sd_slope_bio$species),median)
write.csv(all_sd_slope,"median_stdev_slope.csv")

# Standard deviation of elevation - from https://www.earthenv.org/topography

sd_elev = raster("elevation_1KMsd_GMTEDsd.tif")

xy_bio <- raster::extract(sd_elev, xy)
sd_elev_bio <- cbind(sp_xy, xy_bio)
sd_elev_bio = na.omit(sd_elev_bio)
write.csv(sd_elev_bio, "cacti_stdev_elev.csv")

all_sd_elev = aggregate(sd_elev_bio$xy_bio,list(sd_elev_bio$species),median)
write.csv(all_sd_elev,"median_stdev_elevation.csv")

# Roughness - from https://www.earthenv.org/topography

roughness = raster("roughness_1KMmd_GMTEDmd.tif")

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(roughness, xy)
roughness_bio <- cbind(sp_xy, xy_bio)
roughness_bio = na.omit(roughness_bio)
write.csv(roughness_bio,"cacti_roughness.csv")

all_roughness = aggregate(roughness_bio$xy_bio,list(roughness_bio$species),median)
write.csv(all_roughness,"median_roughness.csv")

# Profile curvature - from https://www.earthenv.org/topography

prof_curv = raster("pcurv_1KMsd_GMTEDmd.tif")

xy_bio <- raster::extract(prof_curv, xy)
prof_curv_bio <- cbind(sp_xy, xy_bio)
prof_curv_bio = na.omit(prof_curv_bio)
write.csv(prof_curv_bio,"cacti_profile_curve.csv")

all_prof_curv = aggregate(prof_curv_bio$xy_bio,list(prof_curv_bio$species),median)
write.csv(all_prof_curv,"median_profile_curve.csv")

# Tangential curvature - from https://www.earthenv.org/topography

tang_curv = raster("tcurv_1KMsd_GMTEDmd.tif")

xy_bio <- raster::extract(tang_curv, xy)
tang_curv_bio <- cbind(sp_xy, xy_bio)
tang_curv_bio = na.omit(tang_curv_bio)
write.csv(tang_curv_bio,"cacti_tang_curve.csv")

all_tang_curv = aggregate(tang_curv_bio$xy_bio,list(tang_curv_bio$species),median)
write.csv(all_tang_curv,"median_tang_curve.csv")