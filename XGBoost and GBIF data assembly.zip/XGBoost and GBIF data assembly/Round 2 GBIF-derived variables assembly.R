# Cactus gbif

library(ape)
library(dplyr)
library(phangorn)
library(raster)
library(sf)
library(sp)
library(phangorn)
library(purrr)

setwd("C:/Users/jamie/OneDrive/Documents/Cacti round 2")

# Read tree and coordinates data
cactus_tree = force.ultrametric(read.tree("ultra_cacti.tre"))
cactus_data = read.csv("Thompson_gbif.csv") # The curated GBIF coordinates

# Write list of species sampled to a file for easy reference later
cactus_taxa = as.character(cactus_tree$tip.label)
write(cactus_taxa,"cactus_tree_taxon_list.txt")

# Sub spaces for underscores to match with the tree
# Change SOME (not all!) of the Pereskia to Leuenbergeria to maximise GBIF coverage of Pereskioideae
cactus_data$species = sub(" ", "_", cactus_data$species)
cactus_data$species = sub("Pereskia_bleo", "Leuenbergeria_bleo", cactus_data$species)
cactus_data$species = sub("Pereskia_guamacho", "Leuenbergeria_guamacho", cactus_data$species)
cactus_data$species = sub("Pereskia_lychnidiflora", "Leuenbergeria_lychnidiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_aureiflora", "Leuenbergeria_aureiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_zinniiflora", "Leuenbergeria_zinniiflora", cactus_data$species)
cactus_data$species = sub("Pereskia_marcanoi", "Leuenbergeria_marcanoi", cactus_data$species)
cactus_data$species = sub("Pereskia_portulacifolia", "Leuenbergeria_portulacifolia", cactus_data$species)

# Write species sampled in GBIF for later use
unique_cactus_species = unique(cactus_data$species)
write(unique_cactus_species,"cactus_gbif_unique_species.txt")

# Find spaces sampled by both the tree and GBIF
cactus_tree_taxa_in_gbif = data.frame(species = intersect(cactus_data$species, cactus_tree$tip.label))
cactus_gbif = semi_join(cactus_data,cactus_tree_taxa_in_gbif,by = "species")

# Prune tree to just taxa overlapping with GBIF
cactus_gbif_tree = keep.tip(cactus_tree,unique(cactus_gbif$species))

# Now keep only one occurrence per species per 1km grid
cactus_sp <- SpatialPointsDataFrame(coords = cactus_gbif[, c("decimalLongitude", "decimalLatitude")], 
                                    data = cactus_gbif)
grid <- raster(extent(cactus_sp), resolution = 1) # 1km x 1km resolution
cactus_gbif$grid_cell <- cellFromXY(grid, coordinates(cactus_sp))
sampled_data = cactus_gbif %>%
  group_by(species, grid_cell) %>%
  sample_n(1)
write.csv(sampled_data, "1_per_grid_cactus_gbif.csv", row.names = FALSE)

# Prepare GBIF data for extracting climatic variables
sp = sampled_data[,c("species","decimalLatitude","decimalLongitude")]
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]

###### Below here: need to replace these with extracting the new CHELSA stuff
bio1 = raster("CHELSA_bio1_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio1, xy)
bio1 <- cbind(sp_xy, xy_bio)
write.csv(bio1,"cactus_bio1.csv")

bio2 = raster("CHELSA_bio2_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio2, xy)
bio2 <- cbind(sp_xy, xy_bio)
write.csv(bio2,"cactus_bio2.csv")

bio3 = raster("CHELSA_bio3_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio3, xy)
bio3 <- cbind(sp_xy, xy_bio)
write.csv(bio3,"cactus_bio3.csv")

bio4 = raster("CHELSA_bio4_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio4, xy)
bio4 <- cbind(sp_xy, xy_bio)
write.csv(bio4,"cactus_bio4.csv")

bio5 = raster("CHELSA_bio5_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio5, xy)
bio5 <- cbind(sp_xy, xy_bio)
write.csv(bio5,"cactus_bio5.csv")

bio6 = raster("CHELSA_bio6_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio6, xy)
bio6 <- cbind(sp_xy, xy_bio)
write.csv(bio6,"cactus_bio6.csv")

bio7 = raster("CHELSA_bio7_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio7, xy)
bio7 <- cbind(sp_xy, xy_bio)
write.csv(bio7,"cactus_bio7.csv")

bio8 = raster("CHELSA_bio8_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio8, xy)
bio8 <- cbind(sp_xy, xy_bio)
write.csv(bio8,"cactus_bio8.csv")

bio9 = raster("CHELSA_bio9_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio9, xy)
bio9 <- cbind(sp_xy, xy_bio)
write.csv(bio9,"cactus_bio9.csv")

bio10 = raster("CHELSA_bio10_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio10, xy)
bio10 <- cbind(sp_xy, xy_bio)
write.csv(bio10,"cactus_bio10.csv")

bio11 = raster("CHELSA_bio11_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio11, xy)
bio11 <- cbind(sp_xy, xy_bio)
write.csv(bio11,"cactus_bio11.csv")

bio12 = raster("CHELSA_bio12_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio12, xy)
bio12 <- cbind(sp_xy, xy_bio)
write.csv(bio12,"cactus_bio12.csv")

bio13 = raster("CHELSA_bio13_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio13, xy)
bio13 <- cbind(sp_xy, xy_bio)
write.csv(bio13,"cactus_bio13.csv")

bio14 = raster("CHELSA_bio14_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio14, xy)
bio14 <- cbind(sp_xy, xy_bio)
write.csv(bio14,"cactus_bio14.csv")

bio15 = raster("CHELSA_bio15_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio15, xy)
bio15 <- cbind(sp_xy, xy_bio)
write.csv(bio15,"cactus_bio15.csv")

bio16 = raster("CHELSA_bio16_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio16, xy)
bio16 <- cbind(sp_xy, xy_bio)
write.csv(bio16,"cactus_bio16.csv")

bio17 = raster("CHELSA_bio17_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio17, xy)
bio17 <- cbind(sp_xy, xy_bio)
write.csv(bio17,"cactus_bio17.csv")

bio18 = raster("CHELSA_bio18_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio18, xy)
bio18 <- cbind(sp_xy, xy_bio)
write.csv(bio18,"cactus_bio18.csv")

bio19 = raster("CHELSA_bio19_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(bio19, xy)
bio19 <- cbind(sp_xy, xy_bio)
write.csv(bio19,"cactus_bio19.csv")

ai = raster("CHELSA_ai_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(ai, xy)
ai <- cbind(sp_xy, xy_bio)
write.csv(ai,"cactus_ai.csv")

pet = raster("CHELSA_pet_penman_mean_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(pet, xy)
pet <- cbind(sp_xy, xy_bio)
write.csv(pet,"cactus_pet.csv")

npp = raster("CHELSA_npp_1981-2010_V.2.1.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(npp, xy)
npp <- cbind(sp_xy, xy_bio)
write.csv(npp,"cactus_npp.csv")

# Calculate median, rename column and remove lat and long columns
all_data = list(bio1=bio1, bio2=bio2, bio3=bio3, bio4=bio4, bio5=bio5,
                 bio6=bio6, bio7=bio7, bio8=bio8, bio9=bio9, bio10=bio10,
                 bio11=bio11, bio12=bio12, bio13=bio13, bio14=bio14, bio15=bio15,
                 bio16=bio16, bio17=bio17, bio18=bio18, bio19=bio19, ai=ai,
                 pet=pet, npp=npp)

median_results = map2(all_data, names(all_data), ~{
  .x %>% 
    group_by(species) %>%
    summarize(median_val = median(`...4`, na.rm = TRUE)) %>%
    rename(!!paste0(.y) := median_val)
})

combined_result = reduce(median_results, function(df1, df2) {
  left_join(df1, df2, by = "species")
})

# Calculate median and add
median_latitude = bio1 %>%
  group_by(species) %>%
  summarize(latitude = median(decimalLatitude, na.rm = TRUE))

median_chelsa = left_join(combined_result, median_latitude, by = "species")
write.csv(median_chelsa,"cacti_median_CHELSA.csv")

# Elevation - from https://www.earthenv.org/topography
elev = raster("elevation_5KMmd_GMTEDmd.tif")
xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(elev, xy)
elev_bio <- cbind(sp_xy, xy_bio)
write.csv(elev_bio,"cactus_elev.csv")

all_elev = aggregate(elev_bio$'...4',list(elev_bio$species),median)
write.csv(all_elev,"median_elev.csv")

# Biomes, with code from https://gis.stackexchange.com/questions/376280/converting-a-component-of-a-shapefile-into-a-geotiff-file-in-r
# Load packages
packs = list("tidyverse", "raster", "sf", "fasterize")
lapply(packs, require, character.only = T)

# Load shapefile
wwf_shp = st_read("Terrestrial_Ecoregions_World.shp", stringsAsFactors = F) # Data from https://globil-panda.opendata.arcgis.com/datasets/af92f20b1b43479581c819941e0f75ea_0/geoservice?geometry=11.953%2C-89.797%2C-11.953%2C78.032

# Rasterize biome field and write to disk
raster(resolution = 1, crs = "+proj=longlat +datum=WGS84", vals = 0) %>% 
  fasterize(wwf_shp, ., field = "BIOME") %>% 
  writeRaster(., "biomes.tif")

biome = raster("biomes.tif") # http://worldmap.harvard.edu/data/geonode:wwf_terr_ecos_oRn

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(biome, xy)
biome_bio <- na.omit(cbind(sp_xy, xy_bio))
write.csv(biome_bio, "cactus_biome.csv")

all_biome = aggregate(biome_bio$'...4',list(biome_bio$species),getmode)
write.csv(all_biome,"biome_mode.csv",quote=FALSE)

# Sand, texture and water - from https://github.com/ISRICWorldSoil/SoilGrids250m

sand = raster("SNDPPT_M_sl1_250m_ll.tif")
texture = raster("TEXMHT_M_sl1_250m_ll.tif")
water = raster("AWCh1_M_sl1_250m_ll.tif")

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]

xy_bio <- raster::extract(sand, xy)
sand_bio <- cbind(sp_xy, xy_bio)

xy_bio <- raster::extract(texture, xy)
texture_bio <- cbind(sp_xy, xy_bio)

xy_bio <- raster::extract(water, xy)
water_bio <- cbind(sp_xy, xy_bio)

sand_bio = na.omit(sand_bio)
texture_bio = na.omit(texture_bio)
water_bio = na.omit(water_bio)

write.csv(sand_bio,"cacti_sand_0cm.csv")
write.csv(water_bio,"cacti_water_0cm.csv")
write.csv(texture_bio,"cacti_texture.csv")

getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}

all_sand = aggregate(sand_bio$'...4',list(sand_bio$species),median)
all_texture = aggregate(texture_bio$'...4',list(texture_bio$species),getmode)
all_water = aggregate(water_bio$'...4',list(water_bio$species),median)

write.csv(all_sand,"median_sand_0cm.csv")
write.csv(all_water,"median_water_0cm.csv")
write.csv(all_texture,"mode_texture.csv")

# Slope - from https://www.earthenv.org/topography

slope = raster("slope_1KMmd_GMTEDmd.tif")
xy_bio <- raster::extract(slope, xy)
slope_bio <- cbind(sp_xy, xy_bio)
slope_bio = na.omit(slope_bio)
write.csv(slope_bio,"cacti_slope.csv")

all_slope = aggregate(slope_bio$'...4',list(slope_bio$species),median)
write.csv(all_slope,"median_slope.csv")

# Standard deviation of slope - from https://www.earthenv.org/topography

sd_slope = raster("slope_1KMsd_GMTEDmd.tif")
xy_bio <- raster::extract(sd_slope, xy)
sd_slope_bio <- cbind(sp_xy, xy_bio)
sd_slope_bio = na.omit(sd_slope_bio)
write.csv(sd_slope_bio, "cacti_stdev_slope.csv")

all_sd_slope = aggregate(sd_slope_bio$'...4',list(sd_slope_bio$species),median)
write.csv(all_sd_slope,"median_stdev_slope.csv")

# Standard deviation of elevation - from https://www.earthenv.org/topography

sd_elev = raster("elevation_1KMsd_GMTEDsd.tif")

xy_bio <- raster::extract(sd_elev, xy)
sd_elev_bio <- cbind(sp_xy, xy_bio)
sd_elev_bio = na.omit(sd_elev_bio)
write.csv(sd_elev_bio, "cacti_stdev_elev.csv")

all_sd_elev = aggregate(sd_elev_bio$'...4',list(sd_elev_bio$species),median)
write.csv(all_sd_elev,"median_stdev_elevation.csv")

# Roughness - from https://www.earthenv.org/topography

roughness = raster("roughness_1KMmd_GMTEDmd.tif")

xy <- sp[c("decimalLongitude","decimalLatitude")]
sp_xy <- sp[c("species", "decimalLongitude","decimalLatitude")]
xy_bio <- raster::extract(roughness, xy)
roughness_bio <- cbind(sp_xy, xy_bio)
roughness_bio = na.omit(roughness_bio)
write.csv(roughness_bio,"cacti_roughness.csv")

all_roughness = aggregate(roughness_bio$'...4',list(roughness_bio$species),median)
write.csv(all_roughness,"median_roughness.csv")

# Profile curvature - from https://www.earthenv.org/topography

prof_curv = raster("pcurv_1KMsd_GMTEDmd.tif")

xy_bio <- raster::extract(prof_curv, xy)
prof_curv_bio <- cbind(sp_xy, xy_bio)
prof_curv_bio = na.omit(prof_curv_bio)
write.csv(prof_curv_bio,"cacti_profile_curve.csv")

all_prof_curv = aggregate(prof_curv_bio$'...4',list(prof_curv_bio$species),median)
write.csv(all_prof_curv,"median_profile_curve.csv")

# Tangential curvature - from https://www.earthenv.org/topography

tang_curv = raster("tcurv_1KMsd_GMTEDmd.tif")

xy_bio <- raster::extract(tang_curv, xy)
tang_curv_bio <- cbind(sp_xy, xy_bio)
tang_curv_bio = na.omit(tang_curv_bio)
write.csv(tang_curv_bio,"cacti_tang_curve.csv")

all_tang_curv = aggregate(tang_curv_bio$'...4',list(tang_curv_bio$species),median)
write.csv(all_tang_curv,"median_tang_curve.csv")