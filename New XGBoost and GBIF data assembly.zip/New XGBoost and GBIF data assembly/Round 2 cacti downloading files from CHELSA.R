# Round 2 cacti downloading files from CHELSA

setwd("C:/Users/jamie/OneDrive/Documents/Cacti round 2")

urls = read.table("envidatS3paths.txt")$V1

sapply(urls, function(url) {
  dest_file = basename(url) # extracts the filename from the URL
  download.file(url, destfile = dest_file, mode = "wb")
})